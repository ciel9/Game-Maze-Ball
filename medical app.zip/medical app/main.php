<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
  <tittle></tittle>
</head>
<header>

</header>

<body>
  <br>
  <h1> Medical Chat Bot</h1>
  <br>
  <hr>
  <br><br>
  <p>hello, i am a bot medic named hela. <br>
    I am here to help you to do a medical checkup regarding your condition. <br>
    May i know what is your name ?</p>
  <br>
  <form action="" method="post">
    <input style="width:500px;height:30px;" type="text" name="command" placehorder="write here . . ." autocomplete="off">
    <button style="border-radius: 20px;color:grey;width:70px;height:30px;">Search</button>
  </form>
  <br><br>
  <p><?php include 'app.php' ?></p>

</body><br><br><br><br>
<footer>@2020 Copyright : Cindy Elsanjaya </footer>

</html>